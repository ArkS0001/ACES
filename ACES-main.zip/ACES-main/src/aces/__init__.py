"""This is the main module of the ACES package.

It contains the main functions and classes needed to extract cohorts.
"""
